# Forge — Hybrid Android APK, Complete Fitness History, Health Connect & AI Coach

Forge packages your original Claude-developed Forge web application (`Forge-App_cb0bb5fe.zip`) into a production-ready, installable Android APK optimized for Vivo Y28 4G and Android 16. It preserves Forge's exact `#0A0B0D` Neon Dark UI, `Archivo` + `Inter` typography, animations, 8 preset programs, exercise library, set logger, rest timer, and charts inside a local offline-bundled `WebView`, connected via native Kotlin bridges to **Google Sign-In**, **Cloud Firestore** (with offline disk cache), **Health Connect**, **Android 16 Notifications**, and a **free-tier Firebase AI Logic Coach** with an on-device rule-based fallback.

---

## User Review & Critical Decisions

> [!IMPORTANT]
> All core architectural decisions below reflect your confirmed choices and final requirements. Please review and approve to begin Firebase provisioning and APK implementation.

- **Confirmed Decision 1 — Hybrid WebView + Native Android Bridges**: Bundle Forge's complete HTML/CSS/JS UI and local font/icon assets directly inside the APK so it launches instantaneously offline, while exposing native Kotlin bridges (`ForgeAndroidBridge`) for Firestore sync, Google Sign-In, Health Connect, notifications, and Gemini AI.
- **Confirmed Decision 2 — Neon Dark Identity Preserved**: Keep Forge's original `#0A0B0D` deep obsidian background, `#131417` / `#1A1C20` layered dark surfaces, `#C7FF35` / `#D4FF4F` neon lime accents, and optional Light theme toggle in Profile.
- **Confirmed Decision 3 — Android 16 Notifications & Health Connect Auto-Sync**: Enable daily workout & goal check-in reminders, periodic water hydration reminders (configurable intervals), and automatic Health Connect step and exercise session synchronization on supported devices (Android 9–16).
- **Confirmed Decision 4 — Free-Tier AI + Offline Fallback & Zero Paid Billing**: Use Firebase AI Logic (`gemini-3.8-flash`, free tier requiring no billing) with App Check, automatically falling back to an on-device rule-based Fitness & Nutrition Coach whenever offline or outside cloud quota.

---

## 1. Overview & Core Concept

- **What It Does**:
  - **Preserved Forge Core**: All original views (`Home`, `Train`, `Exercises`, `Progress`, `History`, `Profile`), onboarding, workout session runner, rest timer with vibration/audio beep, minimized pulsing workout bar, PR detection, and interactive SVG charts.
  - **Expanded Fitness, Custom Goals, Nutrition & Hydration**: Add custom exercises (strength, cardio, walking, running, bodyweight), create/edit/delete time-bound personal goals with start and target dates (e.g., 40 push-ups daily for 30 days), track daily completed vs. missed goals, log meals (Breakfast, Lunch, Dinner, Snacks with calories & protein), track water intake (glasses & liters against custom targets), and record body weight & body measurements.
  - **Complete Fitness History & Analytics System**: Live-computed Daily, Weekly, Monthly, Yearly, and All-Time reports covering push-ups, squats, all exercises, workouts, workout hours, water liters, meals, calories, protein, steps, weight changes, personal records, and achievements—plus an interactive History Calendar allowing users to inspect and edit any past date without ever auto-deleting historical records.
  - **AI Fitness Coach**: Interactive chat, structured personalized workout plan builder (one-tap launch/save), macro-aware diet suggestions (one-tap meal log), and progress analysis grounded in actual saved user metrics.
- **Target Audience / Device**: Designed for daily mobile tracking and gym sessions on Android smartphones—specifically optimized for Vivo Y28 4G (compact/medium touch ergonomics, Android 16 edge-to-edge insets, offline gym reliability, and system back-button handling).

---

## 2. User Experience & Visual Design

- **Key User Flows**:
  1. **Native Google Sign-In Gate**: Clean Neon Dark welcome screen (`#0A0B0D` + `#C7FF35` accent) with automatic silent Credential Manager check on launch and a prominent "Sign in with Google" button so all workouts, goals, meals, and history sync securely across devices.
  2. **Home & Daily Tracker**: Forge's signature hero weekly progress ring, 7-day strip, "Up next" workout card, plus compact Daily Targets cards for Push-Ups, Squats, Steps (synced from Health Connect), Water (glasses + liters with `+1 glass` / `+250ml` quick taps), Calories/Protein, and Daily Goals completed vs. missed.
  3. **Train & Active Workout Session**: Start empty workouts, custom routines, or 8 preset programs; add custom exercises; log sets/reps/weights with previous-session hints and automatic rest timer; save completed workouts to Firestore and optionally write exercise sessions to Health Connect.
  4. **Goals, Meals & Water Hub**: Dedicated, Forge-styled modals/sections to manage time-bound goals (start date, target end date, daily target), log Breakfast/Lunch/Dinner/Snack entries (or custom reusable meals), and adjust hydration/weight/body measurements.
  5. **History Calendar & Analytics Reports**: Interactive calendar to jump to any past date, inspect every logged metric/workout/meal, and edit incorrect entries safely; segmented `Daily / Weekly / Monthly / Yearly / All-Time` analytics view with charts, body measurements trend, PRs, and milestone badges.
  6. **AI Coach Studio**: Accessible from the navigation bar/quick action for Coach Chat, Workout Plan Generator, Diet Suggestions, and Progress Analysis—displaying a clear `Gemini AI` or `Offline Coach Mode` badge depending on connectivity.
  7. **Profile, Health Connect & Reminders**: Toggle Neon Dark / Light appearance, kg/lb units, rest timer duration, Health Connect permissions & manual sync, notification schedules (workout check-ins & water reminders), JSON backup export, and Google Sign-Out.

- **Visual Identity & Theme**:
  - *Aesthetic Direction*: Forge Neon Dark Athletic — exact preservation of Forge's `#0A0B0D` canvas, `#131417` cards, `#1A1C20` nested tiles, `#24272C` crisp 1px borders, and high-energy `#C7FF35` / `#D4FF4F` neon lime highlights.
  - *Typography*: Local bundled `Archivo` (bold athletic display headings & tabular stats) and `Inter` (clean UI copy) loaded from APK assets so text never falls back to generic system fonts offline.
  - *Responsive Mobile Navigation*: Bottom navigation bar respecting Android 16 gesture/navigation bar safe insets, tactile `48dp` minimum touch targets, hardware Back button routing through open modals/sessions/tabs before exiting, and soft keyboard adjustment inside WebView inputs.

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1 — Hybrid Local WebView + Native Kotlin Bridges**
  - *Chosen Approach*: Package the upgraded Forge HTML/CSS/JS bundle inside APK assets (zero external font/CDN dependencies) inside a Compose `AndroidView(WebView)` paired with a typed `@JavascriptInterface` bridge (`ForgeBridge`) and `evaluateJavascript` state push channel.
  - *Why*: Preserves 100% of your original Forge UI, CSS animations, SVG charts, and UX while letting native Kotlin handle Credential Manager, Firestore offline persistence, App Check + Firebase AI Logic, Health Connect, and Android 16 notifications cleanly.
  - *Alternatives Considered*: Pure WebView without native bridges (cannot access Health Connect, Credential Manager, or native Android 16 notifications); full rewrite from scratch (would diverge from the original Forge DOM/CSS fidelity).

- **Decision 2 — Firestore Offline Persistence + Unified Date-Keyed History**
  - *Chosen Approach*: Store all user data in Cloud Firestore under `/users/{uid}/...` with persistent offline disk cache enabled, using date-keyed daily records (`yyyy-MM-dd`) alongside immutable-until-edited `workouts`, `goals`, `meals`, `custom_exercises`, and `body_measurements` collections.
  - *Why*: Ensures offline logging works seamlessly in low-signal gyms, syncs automatically across devices via Google Sign-In, never auto-deletes past records, and dynamically recalculates Daily/Weekly/Monthly/Yearly/All-Time totals whenever a past entry is edited.

- **Decision 3 — Free-Tier Firebase AI Logic + Deterministic On-Device Coach**
  - *Chosen Approach*: Use `gemini-3.8-flash` via Firebase AI Logic + App Check for online AI coaching, structured JSON workout plans, diet ideas, and progress analysis, with an automatic deterministic rule-based coach fallback when offline or if cloud calls fail.
  - *Why*: Zero paid API keys, zero automatic paid billing, and 100% uptime even in airplane mode.

---

## 4. Technical Architecture & Data Strategy *(Technical Reference)*

- **Architecture & Component Diagram**:

```
┌──────────────────────────────────────────────────────────────────────────┐
│                        Android 16 Native Shell (Compose)                 │
│  ┌─────────────────────────┐      ┌───────────────────────────────────┐  │
│  │ Google Sign-In Gate     │─────▶│ Edge-to-Edge WebView Container    │  │
│  │ (Credential Manager)    │      │ + BackHandler & Inset Sync        │  │
│  └─────────────────────────┘      └─────────────────┬─────────────────┘  │
│                                                     │                    │
│                       Local Asset Bundle (Offline-First)                 │
│           Forge UI (index.html + local Archivo/Inter fonts + icons)      │
│                                                     │                    │
│                                      @JavascriptInterface (ForgeBridge)  │
└─────────────────────────────────────────────────────┼────────────────────┘
                                                      │
┌─────────────────────────────────────────────────────▼────────────────────┐
│                    Native Kotlin Services & ViewModel                    │
│  ┌─────────────────────┐  ┌─────────────────────┐  ┌──────────────────┐  │
│  │  FitnessRepository  │  │  AiCoachRepository  │  │ HealthConnectMgr │  │
│  │  (Firestore Offline │  │  (Firebase.ai       │  │ (Steps, Workouts │  │
│  │   Cache + Sync)     │  │   gemini-3.8-flash  │  │  Permissions)    │  │
│  └──────────┬──────────┘  │   + Rule Fallback)  │  └────────┬─────────┘  │
│             │             └──────────┬──────────┘           │            │
│             │                        │                      │            │
│  ┌──────────▼──────────┐  ┌──────────▼──────────┐  ┌────────▼─────────┐  │
│  │ Cloud Firestore DB  │  │ Firebase App Check  │  │ NotificationMgr  │  │
│  │ + Hardened Rules    │  │ (Debug & reCAPTCHA) │  │ (Workout & Water │  │
│  └─────────────────────┘  └─────────────────────┘  │  Reminders)      │  │
│                                                    └──────────────────┘  │
└──────────────────────────────────────────────────────────────────────────┘
```

- **Data Model & State**:
  - **UserProfile** (`/users/{uid}`): displayName, unit (`kg`/`lb`), weeklyWorkoutGoal, restTimerSec, theme (`dark`/`light`), dailyTargets (`pushUps`, `squats`, `waterMl`, `glassSizeMl`, `calories`, `proteinGrams`, `steps`, `workoutMinutes`), notificationSettings (`workoutReminderEnabled`, `workoutHour`, `workoutMinute`, `waterReminderEnabled`, `waterIntervalHours`), healthConnectEnabled, createdAt, updatedAt.
  - **DailyLog** (`/users/{uid}/daily_logs/{dateKey}`): dateKey (`yyyy-MM-dd`), pushUps, squats, otherActivities (list of `{name, category, reps, sets, minutes, distanceKm}`), waterMl, steps, healthConnectSyncedSteps, meals (list of `{id, name, mealType, calories, proteinGrams, carbsGrams, fatGrams}`), notes, updatedAt.
  - **WorkoutSession** (`/users/{uid}/workouts/{workoutId}`): name, dateKey, startMs, endMs, durationSec, volumeKg, totalSets, totalPushUps, totalSquats, caloriesBurned, exercises (list of `{id, name, sets: [{w, r}]}`), prs, createdAt, updatedAt.
  - **PersonalGoal** (`/users/{uid}/goals/{goalId}`): title, metricType (`pushups`, `squats`, `water_ml`, `steps`, `workouts`, `calories`, `protein`, `custom`), targetValue, startDateKey, endDateKey, active, completedDates, createdAt, updatedAt.
  - **BodyMeasurement** (`/users/{uid}/measurements/{dateKey}`): dateKey, weightKg, waistCm, chestCm, armCm, bodyFatPct, note, createdAt, updatedAt.
  - **CustomExercise & CustomRoutine & CustomMeal**: Persisted under user subcollections so custom items sync across devices.
  - **Aggregated Analytics Engine**: Computes Daily, Weekly, Monthly, Yearly, and All-Time totals, daily averages, goal completion %, streak counts, PRs, and milestone achievements purely from the persisted records—reflecting historical edits immediately.

- **Interactive Component & State Mapping**:
  - **Startup & Auth**: `MainActivity` runs `configureAppCheck(this, intent)` before `setContent`. Root Compose checks Firebase Auth + attempts silent Credential Manager sign-in; unauthenticated users see the Neon Dark Google Sign-In screen. Once authenticated, `FitnessViewModel` attaches snapshot listeners scoped to `uid` and pushes unified state JSON to the WebView.
  - **WebView Mutation Flow**: Every action in Forge (completing a set, quick-logging push-ups/squats, adding water, logging/editing a meal on a past date, saving a goal, toggling reminders) calls `window.ForgeBridge.<method>(json)` which writes optimistically to Firestore (stored immediately in offline disk cache) and notifies the WebView.
  - **Health Connect Flow**: When enabled on Android 9–16, `HealthConnectManager` checks `HealthConnectClient.getSdkStatus()`, requests `StepsRecord`, `ExerciseSessionRecord`, and `TotalCaloriesBurnedRecord` permissions via `PermissionController.createRequestPermissionResultContract()`, aggregates today's/recent steps into `daily_logs`, and records completed Forge workouts back to Health Connect.
  - **AI Coach Flow**: Prompts combine user profile targets and summarized Daily/Weekly/All-Time history and stream responses from `Firebase.ai.generativeModel("gemini-3.8-flash")` (or return structured JSON workout/meal plans via `Schema.obj`). Network errors or offline mode transparently invoke `OfflineFitnessCoach` with an explicit `Offline Coach Mode` label.
  - **Notifications Flow**: Requests `POST_NOTIFICATIONS` permission on Android 13–16 when enabled and schedules local `WorkManager` / `AlarmManager` daily workout & goal check-in alerts plus periodic water hydration reminders via dedicated Android notification channels.

- **Key Sequences & Integrations**:
  - **Firebase Setup**: Provision `["firestore", "ai_logic"]`, author `firebase-blueprint.json` + zero-trust `firestore.rules`, validate rules locally with both JavaScript (`firestore.test.js`) and Kotlin Robolectric emulator tests (`*RuleTest.kt`), and deploy verified rules.
  - **APK Verification**: Build the installable Android APK (`gradle :app:assembleDebug`) and run unit/Robolectric tests, ensuring full Play Policy compliance and Vivo Y28 4G / Android 16 compatibility.
